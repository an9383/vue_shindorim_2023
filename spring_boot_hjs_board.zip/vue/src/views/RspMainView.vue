<template>
  <div>
    <RspMain></RspMain>
  </div>
</template>

<script>
import RspMain from '@/components/rsp/RspMain.vue'

export default {
  components: {
    // RspHeader,
    RspMain
    // RspFooter
  }
}
</script>

<style scoped></style>
