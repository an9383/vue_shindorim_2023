package edu.kosmo.hjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHjsBoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHjsBoardApplication.class, args);
	}

}
