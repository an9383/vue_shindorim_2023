package edu.kosmo.hjs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootHjsBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
