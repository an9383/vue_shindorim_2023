<template>
  <div>
    <BoardStoreMain></BoardStoreMain>
  </div>
</template>

<script>
import BoardStoreMain from '../components/board/BoardStoreMain.vue'

export default {
  name: 'BoardMainView',
  components: {
    BoardStoreMain
  }
}
</script>

<style scoped></style>
