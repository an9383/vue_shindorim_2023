<template>
  <lotto-main></lotto-main>
</template>

<script>
import LottoMain from '../components/lotto/LottoMain.vue'

export default {
  name: 'MainView',
  components: {
    LottoMain
  }
}
</script>

<style scoped></style>
