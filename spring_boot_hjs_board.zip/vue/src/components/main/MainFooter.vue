<template>
  <footer class="text-center">
    <hr />
    <p>&copy; Company 2022-2023</p>
  </footer>
</template>

<script>
export default {}
</script>

<style scoped></style>
