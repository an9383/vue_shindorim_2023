package edu.kosmo.hjs.service;


import edu.kosmo.hjs.vo.MemberVO;

public interface MemberService {

	public int writeMember(MemberVO member);

}
